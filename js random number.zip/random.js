function getRandomNumber( lower, upper ) {
  if (isNaN(lower) || isNaN()upper) ) {
    throw new Error('please enter a number.');
  }
  return Math.floor(Math.random() * (upper - lower + 1)) + lower; 
}





